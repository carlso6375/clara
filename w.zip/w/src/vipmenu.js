const vipmenu = (prefix) => { 
	return `            
	
╔══✪〘 USUÁRIO VIP 〙✪══
║
╠➸ *${prefix}dado*
╠➸ *${prefix}cekvip*
╠➸ *${prefix}premiumlist*
╠➸ *${prefix}delete*
╠➸ *${prefix}modapk*
╠➸ *${prefix}indo10*
╠➸ *${prefix}daftarvip [para virar Premium]*
╠➸ *${prefix}qrcode*
╠➥ *${prefix}chentai*
╠➥ *${prefix}gcpf*
╠➥ *${prefix}gbin*
╠➥ *${prefix}pack*
╠➥ *${prefix}destrava*
╠➥ *${prefix}gpessoa*
║
║
╚══✪〘  CARLOS BOT 〙✪══
`
}
exports.vipmenu = vipmenu
